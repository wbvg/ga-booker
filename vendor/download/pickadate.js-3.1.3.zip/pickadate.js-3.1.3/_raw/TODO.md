
a lot of the stuff below may never happen...


- feature: stable `Picker.extend` api
- feature: disable dates using js date objects
- feature: prevent body overflowing scroll
- feature: default theme with “transformly responsive” option
- feature: time picker “period” translations
- feature: move `toString` method to `create` to enable: console.log( 'hi' + picker.get('select') )
- enhance: pass starting `data-value` and `value` from picker -> component

